const user = {
    username: "yoyo",
    password: 090306
};


// const login = () => {
    
// }


document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const name = document.getElementById("name").value;
    const pass = document.getElementById("pass").value;
    const validName = name == user.username;
    const validPass = pass == user.password;

    if (name.trim() === "" || pass.trim() === "") {
        
        alert('Username & password harus diisi');
    } else {
        console.log(validName);
        console.log(validPass);
        if (validName === false || validPass === false) {
        alert('username & password tidak sesuai');
        document.getElementById("name").value = ""; 
        document.getElementById("pass").value = "";
    } else {
        window.location.href = "pages/menuPage.html";
    }}
})

// function login() {
// 	const username = document.getElementById("name");
// 	const password = document.getElementById("pass");
// 	if (username.value === "" || password.value === "") {
// 		window.alert("Username dan Password harus di isi!.");
// 	} else if (
// 		username.value != user.username ||
// 		password.value != user.password
// 	) {
// 		window.alert("Username dan Password tidak sesuai!.");
// 	} else {
// 		location.href = "pages/menuPage.html";
// 	}
// 	username.value = "";
// 	password.value = "";
// }




